#include "Command.h"

Command::Command(System& system): system(system) {}

