#include "SaveCommand.h"
#include <fstream>

SaveCommand::SaveCommand(System& system):Command(system){}

void SaveCommand::execute()
{
	system.saveSystem();
}
