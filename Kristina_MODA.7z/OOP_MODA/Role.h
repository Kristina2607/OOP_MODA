#pragma once

enum class Role
{
	Any,
	Admin,
	Business,
	Client
};